import React from 'react';
import Header from './components/Header';
import Banner from './components/Banner';
import Item from './components/Item';
import Footer from './components/Footer';
import styled from 'styled-components';
const faker = require('faker');

const AppDiv = styled.div`
  width: 1080px;
  margin: 0 auto;
`;

const TitleDiv = styled.div`
  margin: 20px auto;
  text-align:center;
  font-size: 30px;
  font-weight: 800;
`;

function App () {
  return (
    <AppDiv>
      {/* header */}
      <Header />
      <Banner />
      <TitleDiv>Featured Requesters</TitleDiv>
      {/* list */}
      <div style={{ overflow: 'hidden' }}>
        {
          [1, 2, 3, 4, 5, 6].map((item) => {
            const name = faker.name.findName();
            const imgUrl = faker.image.avatar();
            const description = faker.commerce.productDescription();
            return <Item key={item} index={item} name={name} imgUrl={imgUrl} description={description} />
          })
        }
      </div>
      {/* foot */}
      <Footer />
    </AppDiv>
  );
}

export default App;
