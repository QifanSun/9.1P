import React, { Component } from 'react'
import styled from 'styled-components';

const NavGroupUl = styled.ul`
  display:flex;
  flex-direction: row;
  justify-content: space-between;
`;

const Li = styled.li`
  list-style: none;
`;

const LogoDiv = styled.div`
  font-weight: 800;
`;

const SignDiv = styled.div`
  background: #e5e5e5;
  margin-right: 20px;
  padding: 3px 7px;
`;
export default class Header extends Component {
  render () {
    return (
      <NavGroupUl>
        <Li>
          <LogoDiv>ICrowdTask</LogoDiv>
        </Li>
        <Li>How it works</Li>
        <Li>Requesters</Li>
        <Li>Workers</Li>
        <Li>Pricing</Li>
        <Li>About</Li>
        <Li>
          <SignDiv>Sign in</SignDiv>
        </Li>
      </NavGroupUl>
    )
  }
}
