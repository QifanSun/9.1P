import React, { Component } from 'react'
import styled from 'styled-components';

const ItemGroup = styled.dl`
  float: left;
  width: 33.333%;
  padding: 10px 40px;
  box-sizing: border-box;
`;

const ItemImg = styled.img`
  width: 100%;
  height: 200px;
`;

const Dd = styled.dd`
  margin-left: 0;
`;

const ItemTitle = styled.div`
  font-size: 28px;
`;

const ContentDiv = styled.div`
  word-break: break-word;
`;
export default class Item extends Component {
  render () {
    const { index } = this.props;
    return (
      <ItemGroup>
        <dt>
          <ItemImg src={this.props.imgUrl} alt="图片" />
        </dt>
        <Dd className="item-title">
          <ItemTitle>{this.props.name} {index}</ItemTitle>
        </Dd>
        <Dd>
          <ContentDiv>{this.props.description}</ContentDiv>
        </Dd>
      </ItemGroup>
    )
  }
}
