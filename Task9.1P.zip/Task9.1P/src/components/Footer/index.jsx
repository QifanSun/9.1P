import React, { Component } from 'react'
import img1 from './../../assets/images/1.jpg';
import img2 from './../../assets/images/2.jpg';
import img3 from './../../assets/images/3.jpg';
import styled from 'styled-components';


const FooterDiv = styled.div`
  width: 100%;
  height: 50px;
  display: flex;
  flex-direction: row;
  line-height:50px;
`;

const InputGroup = styled.div`
  flex: 3;
  display: flex;
  flex-direction: row;
  background: #e5e5e5;
`;

const NameDiv = styled.div`
  font-size: 20px;
  font-weight: bold;
  margin:0 20px;
`;
const InputEmail = styled.input`
  width: 400px;
  height: 30px;
`;

const BtnButton = styled.button`
  width: 100px;
  height: 30px;
  margin-left: 20px;
`;

const ConnectDiv = styled.div`
  flex: 1;
  margin-left: 20px;
  background: #e5e5e5;
  display: flex;
  flex-direction: row;
`;

const ConnectUs = styled.div`
  font-weight: 600;
  margin: 0 10px;
`;

const Img = styled.img`
  vertical-align: middle;
`;
export default class Footer extends Component {
  render () {
    return (
      <FooterDiv>
        <InputGroup>
          <NameDiv>NEWSLETTER SIGN</NameDiv>
          <div>
            <InputEmail type="text" placeholder="Enter your email" />
          </div>
          <div>
            <BtnButton type="button" className="btn">Subscribe</BtnButton>
          </div>
        </InputGroup>
        <ConnectDiv>
          <ConnectUs>CONNECT US</ConnectUs>
          <div>
            <Img src={img1} alt="pic01" />
          </div>
          <div>
            <Img src={img2} alt="pic02" />
          </div>
          <div>
            <Img src={img3} alt="pic03" />
          </div>
        </ConnectDiv>
      </FooterDiv>
    )
  }
}
