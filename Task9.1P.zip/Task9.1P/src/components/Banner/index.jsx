import React, { Component } from 'react'
import styled from 'styled-components';

import skyImg from './../../assets/images/sky.jpg'

const BannerDiv = styled.div`
  width: 100%;
  height: 400px;
`;

const Img = styled.img`
  width: 100%;
  height: 400px;
`;
export default class Banner extends Component {
  render () {
    return (
      <BannerDiv>
        <Img src={skyImg} alt="pic" />
      </BannerDiv>
    )
  }
}
